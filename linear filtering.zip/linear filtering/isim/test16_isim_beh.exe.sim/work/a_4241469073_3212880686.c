/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Xilinx/WORKING/linear filtering/multiplier_2.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_3293060193_503743352(char *, char *, char *, char *, unsigned char );
char *ieee_p_2592010699_sub_393209765_503743352(char *, char *, char *, char *);


static void work_a_4241469073_3212880686_p_0(char *t0)
{
    char t1[16];
    char t2[16];
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(46, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t3 = (t0 + 4336U);
    t5 = ieee_p_2592010699_sub_3293060193_503743352(IEEE_P_2592010699, t2, t4, t3, (unsigned char)0);
    t6 = (t2 + 12U);
    t7 = *((unsigned int *)t6);
    t7 = (t7 * 1U);
    t8 = xsi_vhdl_bitvec_sll(t8, t5, t7, 1);
    t9 = ieee_p_2592010699_sub_393209765_503743352(IEEE_P_2592010699, t1, t8, t2);
    t10 = (t1 + 12U);
    t11 = *((unsigned int *)t10);
    t11 = (t11 * 1U);
    t12 = (10U != t11);
    if (t12 == 1)
        goto LAB2;

LAB3:    t13 = (t0 + 2752);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t9, 10U);
    xsi_driver_first_trans_fast_port(t13);
    t3 = (t0 + 2672);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_size_not_matching(10U, t11, 0);
    goto LAB3;

}


extern void work_a_4241469073_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4241469073_3212880686_p_0};
	xsi_register_didat("work_a_4241469073_3212880686", "isim/test16_isim_beh.exe.sim/work/a_4241469073_3212880686.didat");
	xsi_register_executes(pe);
}
