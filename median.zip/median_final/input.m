clc,
clear all;
close all;

a=uint8(load('memory.txt'));
b=reshape(a,130,130);
imshow(b);
title('Input image');