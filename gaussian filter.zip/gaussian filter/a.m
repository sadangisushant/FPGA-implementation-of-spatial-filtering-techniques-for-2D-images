d=load('OUTPUT_MASKING1.txt');
d1=double(d);
for i= 1:16384
    if strcmp(d1(i),'00000000')== 1
            count = count+1;
    end
end